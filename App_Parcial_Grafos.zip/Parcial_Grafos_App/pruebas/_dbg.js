const V=require('./validar_gams.js'); const Va=require('../web/js/variantes.js'); const Vrp=require('../web/js/vrp.js');
(async()=>{ const {S,p}=V.instancia('pcvrp'); const {I,notas}=Va.construir('pcvrp',S,p);
 console.log('cap', I.veh.map(v=>v.cap), 'w', I.w, 'prize', I.prize, 'opt', I.optional.slice(0,12), 'f', JSON.stringify(I.f).slice(0,200));
 const r=await Vrp.vrp(I,V.ctx,{tiempo:60,brecha:1e-6,metodo:'mtz'});
 console.log(r.estado, r.objetivo, 'premio', r.premio, 'total', r.total, r.rutas, r.noVisitados);})();
